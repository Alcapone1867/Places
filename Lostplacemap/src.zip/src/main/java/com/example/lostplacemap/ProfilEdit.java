package com.example.lostplacemap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProfilEdit extends AppCompatActivity {

    FirebaseAuth fAuth;
    DatabaseReference reference;

    Button btnSave;
    EditText EditTextBio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_edit);

        btnSave = findViewById(R.id.save);
        EditTextBio = findViewById(R.id.bio);

        fAuth = FirebaseAuth.getInstance();


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bio = EditTextBio.getText().toString();
                saveBio(bio);
            }
        });

    }

    private void saveBio(String bio) {
        FirebaseUser firebaseUser = fAuth.getCurrentUser();
        String userid = firebaseUser.getUid();

        reference = FirebaseDatabase.getInstance().getReference().child("Users").child(userid);

        reference.child("bio").setValue(bio);
        EditTextBio.setText("");

        startActivity(new Intent(ProfilEdit.this, Profil.class));

    }

}
