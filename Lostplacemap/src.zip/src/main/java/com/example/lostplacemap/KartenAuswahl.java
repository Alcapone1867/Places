package com.example.lostplacemap;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class KartenAuswahl extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;

    CardView Lostplaces, AlleOrte;
    ImageView LostplaceIMG, AllIMG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karten_auswahl);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        Lostplaces = findViewById(R.id.lostplaces);
        AlleOrte = findViewById(R.id.alle_orte);
        LostplaceIMG = findViewById(R.id.lostplaces_img);
        AllIMG= findViewById(R.id.all_img);

        Glide.with(AllIMG).load("https://cdn.pixabay.com/photo/2018/01/31/05/43/web-3120321__480.png").centerCrop().into(AllIMG);

        Glide.with(LostplaceIMG).load("https://images.pexels.com/photos/2825737/pexels-photo-2825737.jpeg").centerCrop().into(LostplaceIMG);

        AlleOrte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(KartenAuswahl.this, BestMapsActivity.class));
            }
        });

        Lostplaces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(KartenAuswahl.this, LostplacesMapsActivity.class));
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.karten_auswahl, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent h = new Intent(KartenAuswahl.this, Main.class);
                startActivity(h);
                break;


            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                Intent f = new Intent(KartenAuswahl.this, Login.class);
                startActivity(f);
                break;

            case R.id.nav_profil:
                Intent e = new Intent(KartenAuswahl.this, Profil.class);
                startActivity(e);
                break;

            case R.id.nav_new:
                Intent d = new Intent(KartenAuswahl.this, New_Marker.class);
                startActivity(d);
                break;

            case R.id.nav_new_post:
                Intent c = new Intent(KartenAuswahl.this, NewPost.class);
                startActivity(c);
                break;

            case R.id.nav_follow:
                Intent b = new Intent(KartenAuswahl.this, FollowActivity.class);
                startActivity(b);
                break;

            case R.id.nav_karten_auswahl:
                Intent a = new Intent(KartenAuswahl.this, KartenAuswahl.class);
                startActivity(a);
                break;
        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
