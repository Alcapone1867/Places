package com.example.lostplacemap;

public class PlacesInformation {
    public String name;
    public double latitude;
    public double longitude;
    public String zutritt;
    public String description;
    public String image;
    public String id;


    public PlacesInformation() {
    }

    public PlacesInformation(String name, double latitude, double longitude, String zutritt, String description, String image, String id) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.zutritt = zutritt;
        this.description = description;
        this.image = image;
        this.id = id;
    }

}
