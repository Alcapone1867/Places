package com.example.lostplacemap;


public class ImageUploadInfo {

    public String imageName;
    public String imageURL;
    public int likes;
    public String postid;
    public String publisher;
    public String publisherName;

    public ImageUploadInfo() {

    }


    public String getImageName() {
        return imageName;
    }

    public String getImageURL() {
        return imageURL;
    }


    public int getLikes() {
        return likes;
    }

    public String getPostid() {
        return postid;
    }

    public String getPublisher(){
        return publisher;
    }
    public String getPublisherName(){
        return publisherName;
    }
}
