package com.example.lostplacemap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lostplacemap.Model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    FirebaseAuth fAuth = FirebaseAuth.getInstance();

    DatabaseReference databaseReference2;
    DatabaseReference databaseReferenceLikes;

    Context context;
    List<ImageUploadInfo> MainImageUploadInfoList;

    public RecyclerViewAdapter(Context context, List<ImageUploadInfo> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_items, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;


    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final ImageUploadInfo UploadInfo = MainImageUploadInfoList.get(position);


        holder.imageNameTextView.setText(UploadInfo.getImageName());

        holder.publisher.setText(UploadInfo.getPublisherName());

        databaseReferenceLikes = FirebaseDatabase.getInstance().getReference("Likes").child(UploadInfo.getPostid());
        final FirebaseUser user = fAuth.getCurrentUser();


        //Loading image from Glide library.
        Glide.with(context).load(UploadInfo.getImageURL()).into(holder.imageView);

        databaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.child(UploadInfo.publisher).getValue(User.class);
                Glide.with(context)
                        .load(user.getImageurl())
                        .into(holder.image_profile);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        holder.publisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences user = context.getSharedPreferences("selectedUser",
                        Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = user.edit();
                editor.putString("user", UploadInfo.publisher);
                editor.apply();
                Intent i1 = new Intent (context, UniversalProfil.class);
                context.startActivity(i1);
            }
        });


        holder.image_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        SharedPreferences user = context.getSharedPreferences("selectedUser",
                                Context.MODE_PRIVATE);

                        SharedPreferences.Editor editor = user.edit();
                        editor.putString("user", UploadInfo.publisher);
                        editor.apply();
                        Intent i1 = new Intent (context, UniversalProfil.class);
                        context.startActivity(i1);

                    }
        });


        isLiked(UploadInfo.getPostid(), holder.like);
        nrLikes(holder.AnzahlLikes, UploadInfo.getPostid());

        holder.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.like.getTag().equals("like")) {
                    FirebaseDatabase.getInstance().getReference().child("Likes").child(UploadInfo.getPostid()).child(user.getUid()).setValue(true);
                } else {
                    FirebaseDatabase.getInstance().getReference().child("Likes").child(UploadInfo.getPostid()).child(user.getUid()).removeValue();
                }
            }
        });

    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageView;
        public TextView imageNameTextView;
        public ImageView like;
        public TextView AnzahlLikes;
        public TextView publisher;
        public ImageView image_profile;


        public ViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            like = itemView.findViewById(R.id.ic_like);
            imageNameTextView = itemView.findViewById(R.id.ImageNameTextView);
            AnzahlLikes = itemView.findViewById(R.id.likeCount);
            publisher = itemView.findViewById(R.id.TextUsername);
            image_profile = itemView.findViewById(R.id.image_profile);

            databaseReference2 = FirebaseDatabase.getInstance().getReference("Users");


        }

    }


    private void isLiked(String postid, final ImageView imageView) {
        final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Likes").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(firebaseUser.getUid()).exists()) {
                    imageView.setImageResource(R.drawable.ic_liked);
                    imageView.setTag("liked");
                } else {
                    imageView.setImageResource(R.drawable.ic_like);
                    imageView.setTag("like");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void nrLikes(final TextView likes, String postid) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Likes").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                likes.setText(String.valueOf(dataSnapshot.getChildrenCount()));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}