package com.example.lostplacemap;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lostplacemap.Model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;


public class RecyclerViewAdapterProfil extends RecyclerView.Adapter<RecyclerViewAdapterProfil.ViewHolder> {

    DatabaseReference dataRef;
    Context context;
    List<ImageUploadInfo> MainImageUploadInfoList;

    public RecyclerViewAdapterProfil(Context context, List<ImageUploadInfo> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_items_profil, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;


    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final ImageUploadInfo UploadInfo = MainImageUploadInfoList.get(position);

        holder.imageNameTextView.setText(UploadInfo.getImageName());
        holder.publisher.setText(UploadInfo.getPublisherName());

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataRef.child("All_Image_Uploads_Database").child(UploadInfo.postid).removeValue();
                dataRef.child("Likes").child(UploadInfo.postid).removeValue();
                dataRef.child("Users").child(UploadInfo.getPublisher()).child("Posts").child(UploadInfo.postid).removeValue();

                Toast.makeText(context, "Gelöscht", Toast.LENGTH_SHORT).show();

                Intent i1 = new Intent(context, Profil.class);
                context.startActivity(i1);
            }
        });


        //Loading image from Glide library.
        Glide.with(context).load(UploadInfo.getImageURL()).into(holder.imageView);

        dataRef.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.child(UploadInfo.publisher).getValue(User.class);
                Glide.with(context)
                        .load(user.getImageurl())
                        .into(holder.image_profile);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageView;
        public TextView imageNameTextView;
        public TextView publisher;
        public ImageView image_profile;
        public Button btnDelete;


        public ViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            imageNameTextView = itemView.findViewById(R.id.ImageNameTextView);
            publisher = itemView.findViewById(R.id.TextUsername);
            image_profile = itemView.findViewById(R.id.image_profile);
            btnDelete = itemView.findViewById(R.id.btn_delete);
            dataRef = FirebaseDatabase.getInstance().getReference();

        }

    }


}
