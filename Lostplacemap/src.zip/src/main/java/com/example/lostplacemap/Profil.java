package com.example.lostplacemap;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.example.lostplacemap.Model.User;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Profil extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ImageView profilePic;
    Button btnEdit;
    LinearLayout followerLayout, abonniertLayout, beitrageLayout, besuchteOrteLayout;
    TextView fullName, bio, follower, abonniert, beitrage, username, besuchteOrte;

    DatabaseReference mDatabaseRef;

    DrawerLayout drawer;
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        beitrage = findViewById(R.id.beitrage);
        follower = findViewById(R.id.follower);
        abonniert = findViewById(R.id.abonniert);
        fullName = findViewById(R.id.fullName);
        username = findViewById(R.id.username);
        bio = findViewById(R.id.bio);
        btnEdit = findViewById(R.id.btn_edit);
        profilePic = findViewById(R.id.image_profile);
        besuchteOrte = findViewById(R.id.besuchte_orte);
        followerLayout = findViewById(R.id.follower_layout);
        abonniertLayout = findViewById(R.id.abonniert_layout);
        beitrageLayout = findViewById(R.id.beitrage_layout);
        besuchteOrteLayout = findViewById(R.id.besuchte_orte_layout);


        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Users");

        DatabaseReference followRef = FirebaseDatabase.getInstance().getReference("Follow").child(currentUser.getUid());
        followRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String followers = String.valueOf(dataSnapshot.child("followers").getChildrenCount());
                follower.setText(followers);

                String following = String.valueOf(dataSnapshot.child("following").getChildrenCount());
                abonniert.setText(following);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String uid = currentUser.getUid();
                User user = dataSnapshot.child(uid).getValue(User.class);

                username.setText(user.getUsername());
                fullName.setText(user.getFullname());
                bio.setText(user.getBio());
                beitrage.setText(String.valueOf(dataSnapshot.child(uid).child("Posts").getChildrenCount()));
                besuchteOrte.setText(String.valueOf(dataSnapshot.child(uid).child("besuchteOrte").getChildrenCount()));
                Glide.with(profilePic).load(user.getImageurl()).into(profilePic);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, NewProfilPic.class));
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, ProfilEdit.class));
            }
        });


        followerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, FollowerLayout.class));
            }
        });

        beitrageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, BeitrageLayout.class));
            }
        });

        abonniertLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, AbonniertLayout.class));
            }
        });


        besuchteOrteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Profil.this, BesuchteOrteLayout.class));
            }
        });


    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profil, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent h = new Intent(Profil.this, Main.class);
                startActivity(h);
                break;


            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                Intent f = new Intent(Profil.this, Login.class);
                startActivity(f);
                break;

            case R.id.nav_profil:
                Intent e = new Intent(Profil.this, Profil.class);
                startActivity(e);
                break;

            case R.id.nav_new:
                Intent d = new Intent(Profil.this, New_Marker.class);
                startActivity(d);
                break;

            case R.id.nav_new_post:
                Intent c = new Intent(Profil.this, NewPost.class);
                startActivity(c);
                break;

            case R.id.nav_follow:
                Intent b = new Intent(Profil.this, FollowActivity.class);
                startActivity(b);
                break;

            case R.id.nav_karten_auswahl:
                Intent a = new Intent(Profil.this, KartenAuswahl.class);
                startActivity(a);
                break;
        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}