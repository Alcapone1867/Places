package com.example.lostplacemap;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.lostplacemap.Model.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;


public class NewPost extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    Uri imageUri;
    String myUrl = "";
    StorageTask uploadTask;
    StorageReference storageReference;

    ImageView image_added;
    Button post;
    EditText description;
    FirebaseAuth fAuth;

    // Root Database Name for Firebase Database.
    public static final String Database_Path = "All_Image_Uploads_Database";


    DrawerLayout drawer;
    NavigationView navigationView;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            imageUri = result.getUri();

            image_added.setImageURI(imageUri);
        } else {
            Toast.makeText(this, "Bitte wähle ein Bild aus", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(NewPost.this, Main.class));
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_post);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        fAuth = FirebaseAuth.getInstance();

        image_added = findViewById(R.id.image_added);
        post = findViewById(R.id.post);
        description = findViewById(R.id.description);

        storageReference = FirebaseStorage.getInstance().getReference("posts");

        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadImage();
            }
        });

        CropImage.activity().setAspectRatio(4, 3).start(NewPost.this);


    }


    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadImage() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Hochladen...");
        progressDialog.show();

        if (imageUri != null) {
            final StorageReference filereference = storageReference.child(System.currentTimeMillis() + "." + getFileExtension(imageUri));

            uploadTask = filereference.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    return filereference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        myUrl = downloadUri.toString();


                        FirebaseUser firebaseUser = fAuth.getCurrentUser();
                        final String userid = firebaseUser.getUid();


                        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference();


                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                final String postid = reference.child("All_Image_Uploads_Database").push().getKey();
                                final HashMap<String, Object> hashMap = new HashMap<>();

                                long PostsCounter = dataSnapshot.child("All_Image_Uploads_Database").getChildrenCount();

                                if (PostsCounter != 0) {
                                    hashMap.put("counter", -1 * PostsCounter);
                                } else {
                                    hashMap.put("counter", 0);
                                }

                                hashMap.put("postid", postid);
                                hashMap.put("imageURL", myUrl);
                                hashMap.put("imageName", description.getText().toString());
                                hashMap.put("publisher", FirebaseAuth.getInstance().getCurrentUser().getUid());
                                final User user = dataSnapshot.child("Users").child(userid).getValue(User.class);
                                hashMap.put("publisherName", user.getUsername());


                                reference.child("All_Image_Uploads_Database").child(postid).setValue(hashMap);
                                reference.child("Users").child(userid).child("Posts").child(postid).setValue(true);


                                progressDialog.dismiss();
                                startActivity(new Intent(NewPost.this, Main.class));
                                finish();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });


                        finish();
                    } else {
                        Toast.makeText(NewPost.this, "Fehler", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(NewPost.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(NewPost.this, "Nichts ausgewählt", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.new_post, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent h = new Intent(NewPost.this, Main.class);
                startActivity(h);
                break;


            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                Intent f = new Intent(NewPost.this, Login.class);
                startActivity(f);
                break;

            case R.id.nav_profil:
                Intent e = new Intent(NewPost.this, Profil.class);
                startActivity(e);
                break;

            case R.id.nav_new:
                Intent d = new Intent(NewPost.this, New_Marker.class);
                startActivity(d);
                break;

            case R.id.nav_new_post:
                Intent c = new Intent(NewPost.this, NewPost.class);
                startActivity(c);
                break;

            case R.id.nav_follow:
                Intent b = new Intent(NewPost.this, FollowActivity.class);
                startActivity(b);
                break;

            case R.id.nav_karten_auswahl:
                Intent a = new Intent(NewPost.this, KartenAuswahl.class);
                startActivity(a);
                break;
        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


}
