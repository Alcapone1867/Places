package com.example.lostplacemap;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

//import android.widget.Toolbar;

public class New_Marker extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    DrawerLayout drawer;
    NavigationView navigationView;


    private DatabaseReference mDatabase;

    private Button btnsave;
    private EditText EditTextName;
    private EditText EditTextZutritt;
    private EditText EditTextLatitude;
    private EditText EditTextImageURL;
    private EditText EditTextLongitude;
    private EditText EditTextDescription;
    private CheckBox checkBoxLP, checkBoxAlleOrte;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new__marker);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        btnsave = findViewById(R.id.btnsave);
        EditTextName = findViewById(R.id.EditTextName);
        EditTextLatitude = findViewById(R.id.editTextLatitude);
        EditTextLongitude = findViewById(R.id.editTextLongitude);
        EditTextZutritt = findViewById(R.id.editTextZutritt);
        EditTextDescription = findViewById(R.id.description);
        EditTextImageURL = findViewById(R.id.imageUrl);
        checkBoxAlleOrte = findViewById(R.id.radioAlleOrte);
        checkBoxLP = findViewById(R.id.radioLostplaces);


        mDatabase = FirebaseDatabase.getInstance().getReference();
        btnsave.setOnClickListener(this);
    }

    private void saveUserInformation() {

        final String name = EditTextName.getText().toString().trim();
        double latitude = Double.parseDouble(EditTextLatitude.getText().toString().trim());
        double longitude = Double.parseDouble(EditTextLongitude.getText().toString().trim());
        String zutritt = EditTextZutritt.getText().toString().trim();
        final String description = EditTextDescription.getText().toString().trim();
        String image = EditTextImageURL.getText().toString().trim();

        final String currentTimeMillis = String.valueOf(System.currentTimeMillis());

        final PlacesInformation placesInformation = new PlacesInformation(name, latitude, longitude, zutritt, description, image, currentTimeMillis);

        if (checkBoxLP.isChecked()){
            mDatabase.child("Orte").child(currentTimeMillis).setValue(placesInformation);
            Toast.makeText(New_Marker.this, "gespeichert", Toast.LENGTH_SHORT).show();

            if (checkBoxAlleOrte.isChecked()){
                mDatabase.child("AlleOrte").child(currentTimeMillis).setValue(placesInformation);
                Toast.makeText(New_Marker.this, "gespeichert", Toast.LENGTH_SHORT).show();
            }

        }else if (checkBoxAlleOrte.isChecked()){
            mDatabase.child("AlleOrte").child(currentTimeMillis).setValue(placesInformation);
            Toast.makeText(New_Marker.this, "gespeichert", Toast.LENGTH_SHORT).show();

        }else {
           checkBoxLP.setError("Du muss etwas auswählen!");
        }



    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.new__marker, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //here is the main place where we need to work on.
        int id = item.getItemId();
        switch (id) {

            case R.id.nav_home:
                Intent h = new Intent(com.example.lostplacemap.New_Marker.this, com.example.lostplacemap.Main.class);
                startActivity(h);
                break;


            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                Intent f = new Intent(com.example.lostplacemap.New_Marker.this, Login.class);
                startActivity(f);
                break;

            case R.id.nav_profil:
                Intent e = new Intent(com.example.lostplacemap.New_Marker.this, Profil.class);
                startActivity(e);
                break;

            case R.id.nav_new:
                Intent d = new Intent(com.example.lostplacemap.New_Marker.this, New_Marker.class);
                startActivity(d);
                break;

            case R.id.nav_new_post:
                Intent c = new Intent(New_Marker.this, NewPost.class);
                startActivity(c);
                break;

            case R.id.nav_follow:
                Intent b = new Intent(New_Marker.this, FollowActivity.class);
                startActivity(b);
                break;

            case R.id.nav_karten_auswahl:
                Intent a = new Intent(New_Marker.this, KartenAuswahl.class);
                startActivity(a);
                break;

        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        // if (v == btnproceed) {
        //     finish();
        // }
        if (v == btnsave) {
            saveUserInformation();
            EditTextLatitude.getText().clear();
            EditTextLongitude.getText().clear();
            EditTextName.getText().clear();
            EditTextZutritt.getText().clear();
            EditTextDescription.getText().clear();
            EditTextImageURL.getText().clear();

            Intent i = new Intent(New_Marker.this, KartenAuswahl.class);
            startActivity(i);
        }
    }
}