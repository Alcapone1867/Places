package com.example.lostplacemap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class BestMapsActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;
    private DatabaseReference mOrteRef;
    private FirebaseAuth fAuth;
    private Circle mCircle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_best_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        mOrteRef = FirebaseDatabase.getInstance().getReference();
        fAuth = FirebaseAuth.getInstance();

        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, 1);

    }

    private void drawMarkerWithCircle(LatLng position) {
        double radiusInMeters = 250.0;
        int strokeColor = 0xffff0000; //Rot außen
        int shadeColor = 0x44ff0000; //Rot zum füllen

        CircleOptions circleOptions = new CircleOptions().center(position).radius(radiusInMeters).fillColor(shadeColor).strokeColor(strokeColor).strokeWidth(8);
        mCircle = mMap.addCircle(circleOptions);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMyLocationEnabled(true);

        mMap.setOnMarkerClickListener(this);


        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        mOrteRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot s : dataSnapshot.child("AlleOrte").getChildren()) {
                    PlacesInformation Orte = s.getValue(PlacesInformation.class);

                    double mLatitude = Orte.latitude;
                    double mLongitude = Orte.longitude;

                    MarkerOptions options = new MarkerOptions();

                    options.position(new LatLng(mLatitude, mLongitude));
                    options.title(Orte.name);
                    options.snippet("Zutritt: " + Orte.zutritt);

                    mMap.addMarker(options).setTag(Orte.id);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    @Override
    public boolean onMarkerClick(final Marker marker) {

        mOrteRef.child("AlleOrte").child(marker.getTag().toString()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                PlacesInformation mOrte = dataSnapshot.getValue(PlacesInformation.class);

                double mLatitude1 = mOrte.latitude;
                double mLongitude1 = mOrte.longitude;

                LatLng latLng = new LatLng(mLatitude1, mLongitude1);
                drawMarkerWithCircle(latLng);

                Location location = mMap.getMyLocation();


                float[] distance = new float[2];

                Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                        mCircle.getCenter().latitude, mCircle.getCenter().longitude, distance);

                if (distance[0] > mCircle.getRadius()) {
                    Toast.makeText(getBaseContext(), "Du befindest dich nicht bei diesen Ort. Er ist: " + distance[0] + "m von dir entfernt" + "\n" +
                                    "Du must innerhalb von " + mCircle.getRadius() + "m sein um ihn als \"besucht\" zu markieren!"
                            , Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getBaseContext(), "Du befindest dich bei diesen Orte. Er ist: " + distance[0] + "m von dir entfernt und wurde als  \"besucht\"  markiert! ", Toast.LENGTH_LONG).show();

                    FirebaseUser currentUser = fAuth.getCurrentUser();
                    mOrteRef.child("Users").child(currentUser.getUid()).child("besuchteOrte").child(marker.getTitle()).setValue(true);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        marker.showInfoWindow();

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                SharedPreferences settings = getSharedPreferences("selectedLocation",
                        Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = settings.edit();
                editor.putString("location", (String) marker.getTag());
                editor.apply();


                startActivity(new Intent(BestMapsActivity.this, UniversalLocationBest.class));
            }
        });

        return true;
    }
}