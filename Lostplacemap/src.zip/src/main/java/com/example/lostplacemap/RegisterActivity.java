package com.example.lostplacemap;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.lostplacemap.Model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    EditText mEmail, mPassword, mPhone, mUsername1, fullname;
    Button mRegisterButton;
    TextView TextLogin;
    FirebaseAuth fAuth;
    ProgressDialog pd;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mEmail = findViewById(R.id.Email);
        mPassword = findViewById(R.id.password);
        mPhone = findViewById(R.id.pww);
        mRegisterButton = findViewById(R.id.RegisterBtn);
        TextLogin = findViewById(R.id.txt_login);
        mUsername1 = findViewById(R.id.Username);
        fullname = findViewById(R.id.fullname);


        fAuth = FirebaseAuth.getInstance();

        if (fAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), Main.class));
            finish();
        }

        TextLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, Login.class));
            }
        });
        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final String email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();
                String pw2 = mPhone.getText().toString().trim();
                String username = mUsername1.getText().toString();


                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Email muss angegeben werden!");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Password muss angegeben werden!");
                    return;
                }
                if (password.length() < 6) {
                    mPassword.setError("Passwort muss länger als 6 Zeichen sein!");
                    return;
                }
                if (!pw2.equals(password)) {
                    mPassword.setError("Passwörter stimmen nicht überein!");
                    return;
                }

                if (password.equals(username)){
                    mPassword.setError("Passwort darf nicht mit Benutzernamen übereinstimmen!");
                    return;
                }

                ArrayList<String> pwlist = new ArrayList<>();
                pwlist.add("123456");
                pwlist.add("1234567");
                pwlist.add("12345678");
                pwlist.add("qwerty");
                pwlist.add("111111");
                pwlist.add("123456789");
                pwlist.add("abc123");
                pwlist.add("1234567");
                pwlist.add("password1");
                pwlist.add("iloveyou");
                pwlist.add("monkey");
                pwlist.add("dragon");
                pwlist.add("123123 ");
                pwlist.add("qwerty123");
                pwlist.add("qwert123");
                pwlist.add("qwertz");
                pwlist.add("1q2w3e4r");
                pwlist.add("admin");
                pwlist.add("654321");
                pwlist.add("555555");
                pwlist.add("lovely");
                pwlist.add("7777777");
                pwlist.add("welcome");
                pwlist.add("888888");
                pwlist.add("princess");
                pwlist.add("princess");
                pwlist.add("123qwe");
                pwlist.add("ficken");
                pwlist.add("hallo123");
                pwlist.add("passwort");
                pwlist.add("master");
                pwlist.add("Passwort123");
                pwlist.add("passwort123");
                pwlist.add("000000");
                pwlist.add("target123");
                pwlist.add("");


                if (pwlist.contains(password)){
                    mPassword.setError("Dein Passwort ist zu unsicher!");
                    return;
                }

                pd = new ProgressDialog(RegisterActivity.this);
                pd.setMessage("Bitte warten...");
                pd.show();

                String str_username = mUsername1.getText().toString();
                String str_password = mPassword.getText().toString();
                String str_fullname = fullname.getText().toString();
                String str_email = mEmail.getText().toString();

                if (TextUtils.isEmpty(str_username) || TextUtils.isEmpty(str_fullname) || TextUtils.isEmpty(str_email) || TextUtils.isEmpty(str_password)) {
                    Toast.makeText(RegisterActivity.this, "Bitte fülle alles aus!", Toast.LENGTH_SHORT).show();
                    pd.dismiss();
                } else {
                    register(str_username, str_fullname, str_email, str_password);
                }


            }
        });


    }


    private void register(final String username, final String fullname, String email, String password) {
        fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser firebaseUser = fAuth.getCurrentUser();
                    String userid = firebaseUser.getUid();

                    reference = FirebaseDatabase.getInstance().getReference().child("Users").child(userid);

                   // FirebaseDatabase.getInstance().getReference().child("Follow").child(userid)
                   //         .child("following").child(userid).setValue(true);

                    HashMap<String, Object> hashMap = new HashMap<>();
                    hashMap.put("id", userid);
                    hashMap.put("username", username);
                    hashMap.put("fullname", fullname);
                    hashMap.put("bio", "");
                    hashMap.put("posts", "0");
                    hashMap.put("imageurl", "https://cdn.pixabay.com/photo/2016/08/08/09/17/avatar-1577909_1280.png");

                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            User user = dataSnapshot.getValue(User.class);

                            if (user != null) {
                                user.setUsername(username);
                            }

                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });


                    reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                pd.dismiss();
                                Intent intent = new Intent(RegisterActivity.this, Main.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            } else {
                                pd.dismiss();
                                Toast.makeText(RegisterActivity.this, "Fehler", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    pd.dismiss();
                    Toast.makeText(RegisterActivity.this, "Bitte nimm eine andere Email-Adresse", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }


}
